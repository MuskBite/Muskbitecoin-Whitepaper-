# MuskBite

**MuskBite — Where memes launch to the moon.**

This repository contains the official whitepaper and roadmap for MuskBite, a meme-powered token built on the BNB chain and launched through the Four.Meme platform.

- **Total Supply:** 1,000,000,000 BITE  
- **Chain:** Binance Smart Chain (BNB)  
- **Contract Address:** [0x4fedc312bd0aed9e9a5a00e192bce0b3ae664444](https://four.meme/token/0x4fedc312bd0aed9e9a5a00e192bce0b3ae664444)  
- **Developer Allocation:** 0.14%  
- **Twitter:** [@muskbitecoin](https://x.com/muskbitecoin)

> Grab the bite. Join the hype.

---

## Documents

- [WHITEPAPER.md](WHITEPAPER.md)
- [ROADMAP.md](ROADMAP.md)
